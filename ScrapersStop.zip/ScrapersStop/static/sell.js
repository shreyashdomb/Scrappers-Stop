function all() {
  alert("This Feature Is Still Under Work")
}
