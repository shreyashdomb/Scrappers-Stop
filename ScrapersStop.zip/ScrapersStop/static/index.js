function hell() {
  alert("hie there");
}
